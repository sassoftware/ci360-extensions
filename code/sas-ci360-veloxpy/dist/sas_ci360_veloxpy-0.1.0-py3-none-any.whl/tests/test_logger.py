#import sasci360veloxpylogging
from sas_ci360_veloxpy.utils.logging import SASCI360VeloxPyLogging
import configparser
import sys 

loggingFramework =  SASCI360VeloxPyLogging()

loggingFramework.startLogger("nonexisting.ini")
loggingFramework.writeLogMessage("This is a test log message at TRACE level for default log.", "TRACE")
loggingFramework.writeLogMessage("This is a test log message at DEBUG level for default log.", "DEBUG")
loggingFramework.writeLogMessage("This is a test log message at INFO level for default log.", "INFO")
loggingFramework.writeLogMessage("This is a test log message at WARN level for default log.", "WARN") 
loggingFramework.writeLogMessage("This is a test log message at ERROR level for default log.", "ERROR")
loggingFramework.writeLogMessage("This is a test log message at CRITICAL level for default log.", "CRITICAL")
loggingFramework.writeLogMessage("This is a test log message at undefined logging level for default log.", "SYS")
loggingFramework.stopLogger()

loggingFramework.startLogger()
loggingFramework.writeLogMessage("This is a test log message at TRACE level for default log.", "TRACE")
loggingFramework.writeLogMessage("This is a test log message at DEBUG level for default log.", "DEBUG")
loggingFramework.writeLogMessage("This is a test log message at INFO level for default log.", "INFO")
loggingFramework.writeLogMessage("This is a test log message at WARN level for default log.", "WARN") 
loggingFramework.writeLogMessage("This is a test log message at ERROR level for default log.", "ERROR")
loggingFramework.writeLogMessage("This is a test log message at CRITICAL level for default log.", "CRITICAL")
loggingFramework.writeLogMessage("This is a test log message at undefined logging level for default log.", "SYS")
loggingFramework.stopLogger()



# loggingFramework.startLogger("consollogging.ini")
# loggingFramework.disableFileLogging()
# loggingFramework.writeLogMessage("This is a test log message at TRACE level only to console.", "TRACE")
# loggingFramework.writeLogMessage("This is a test log message at DEBUG level only to console.", "DEBUG")
# loggingFramework.writeLogMessage("This is a test log message at INFO level only to console.", "INFO")
# loggingFramework.writeLogMessage("This is a test log message at WARN level only to console.", "WARN") 
# loggingFramework.writeLogMessage("This is a test log message at ERROR level only to console.", "ERROR")
# loggingFramework.writeLogMessage("This is a test log message at CRITICAL level only to console.", "CRITICAL")
# loggingFramework.writeLogMessage("This is a test log message at undefined logging level only to console.", "SYS")
# loggingFramework.stopLogger()


# loggingFramework.startLogger("filelogging.ini")
# loggingFramework.writeLogMessage("This is a test log message at TRACE level only to file.", "TRACE")
# loggingFramework.writeLogMessage("This is a test log message at DEBUG level only to file.", "DEBUG")
# loggingFramework.writeLogMessage("This is a test log message at INFO level only to file.", "INFO")
# loggingFramework.writeLogMessage("This is a test log message at WARN level only to file.", "WARN") 
# loggingFramework.writeLogMessage("This is a test log message at ERROR level only to file.", "ERROR")
# loggingFramework.writeLogMessage("This is a test log message at CRITICAL level only to file.", "CRITICAL")
# loggingFramework.writeLogMessage("This is a test log message at undefined logging level only to file.", "SYS")
# loggingFramework.stopLogger()

# loggingFramework.startLogger("nologging.ini")
# loggingFramework.writeLogMessage("This is a test log message at TRACE level with output going neither to console nor to file.", "TRACE")
# loggingFramework.writeLogMessage("This is a test log message at DEBUG level with output going neither to console nor to file.", "DEBUG")
# loggingFramework.writeLogMessage("This is a test log message at INFO level with output going neither to console nor to file.", "INFO")
# loggingFramework.writeLogMessage("This is a test log message at WARN level with output going neither to console nor to file.", "WARN") 
# loggingFramework.writeLogMessage("This is a test log message at ERROR level with output going neither to console nor to file.", "ERROR")
# loggingFramework.writeLogMessage("This is a test log message at CRITICAL level with output going neither to console nor to file.", "CRITICAL")
# loggingFramework.writeLogMessage("This is a test log message at undefined logging level with output going neither to console nor to file.", "SYS")
# loggingFramework.stopLogger()

# loggingFramework.startLogger("autodebug.ini")
# loggingFramework.writeLogMessage("This is a test log message at TRACE level with autodebug output.", "TRACE")
# loggingFramework.writeLogMessage("This is a test log message at DEBUG level autodebug output.", "DEBUG")
# loggingFramework.writeLogMessage("This is a test log message at INFO level with autodebug output.", "INFO")
# loggingFramework.writeLogMessage("This is a test log message at WARN level with autodebug output.", "WARN") 
# loggingFramework.writeLogMessage("This is a test log message at ERROR level with autodebug output.", "ERROR")
# loggingFramework.writeLogMessage("This is a test log message at CRITICAL level with autodebug output.", "CRITICAL")
# loggingFramework.writeLogMessage("This is a test log message at undefined logging level with autodebug output.", "SYS")
# loggingFramework.stopLogger()


# vConfigParser = configparser.ConfigParser(interpolation=None)
# try:
#     vConfigParser.read("myApp.ini", encoding='utf-8')
# except Exception as e:
#     print(f"Error reading configuration file: {e}")
#     sys.exit(1)
# loggingFramework.startLogger(vConfigParser)
# loggingFramework.writeLogMessage("This is a test log message at TRACE level using configparser object.", "TRACE")
# loggingFramework.writeLogMessage("This is a test log message at DEBUG level using configparser object.", "DEBUG")
# loggingFramework.writeLogMessage("This is a test log message at INFO level using configparser object.", "INFO")
# loggingFramework.writeLogMessage("This is a test log message at WARN level using configparser object.", "WARN") 
# loggingFramework.writeLogMessage("This is a test log message at ERROR level using configparser object.", "ERROR")
# loggingFramework.writeLogMessage("This is a test log message at CRITICAL level using configparser object.", "CRITICAL")
# loggingFramework.writeLogMessage("This is a test log message at undefined logging level using configparser object.", "SYS")
# loggingFramework.stopLogger()

