import configparser
from sas_ci360_veloxpy.io.access import decode_base64, encode_base64, getKey,read_text_file
import base64

# abc = read_text_file("c:/sas-ci360-veloxpy/confidential/secret.txt")

# print("abc",abc)

config = configparser.ConfigParser()
config.sections()

# configqwe = configparser.ConfigParser()
# configqwe.sections()

config.read('./sas_ci360_veloxpy/sasci360veloxpy.ini')
# print("sections",config.sections())
authentication = str(config['authentication']['authentication_file'])
# print("authentication",authentication)
abc = read_text_file(authentication)
# print("abc",abc)
zxc=decode_base64(abc)
# print("zxc",zxc)
config.read_string(zxc)
print("zxc111",((config['tenant']['client_id'])))
print("zxc111",((config['tenant']['client_secret'])))
tenant_dict = dict(config.items("tenant"))
print("tenant_dict",tenant_dict['client_secret'])
# voa_key = getKey(str(config['authentication']['authentication_file']))

# if not voa_key:
#     print("There are no azure keys configured. Please configure and run the code again.")


# print("voa_key",voa_key)


# qwe= decode_base64(abc)

# print("qwe",qwe)

# config = configparser.ConfigParser()
# config.read_string(qwe)

# # Access individual values
# server_id = config.get("tenant", "client_id")
# name = config.get("tenant", "client_secret")
# url = config.get("tenant", "token_url")

# print("ID:", server_id)
# print("Name:", name)
# print("URL:", url)

input("Press Enter to continue...")



