# # tests/test_auth_manager.py

# import unittest
# # from sas_ci360_veloxpy.auth.token_manager import SASCI360VeloxPyAuthManager
# # from sas_ci360_veloxpy import load_config

# class TestSASCI360VeloxPyAuthManager(unittest.TestCase):
   
#     def setUp(self):
#         # self.config = load_config()
#         # self.auth_manager = SASCI360VeloxPyAuthManager()
#         # print(self.auth_manager, self.config)

#     def test_def1(self):
#         result = self.auth_manager.generateStaticJWT()
#         self.assertEqual(result, "result from generateStaticJWT")

#     def test_def2(self):
#         result = self.auth_manager.generateTemporaryJWToken()
#         self.assertEqual(result, "generateTemporaryJWToken used: result from generateStaticJWT")

# if __name__ == '__main__':
#     unittest.main()
