chrome.devtools.panels.create("CI360",
    "images/snowy16.png",
    "snowy.html",
    function(panel) {
      // code invoked on panel creation
    }
);
